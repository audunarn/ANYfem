from pathlib import Path
import subprocess,sys,json,zipfile,hashlib
root=Path(__file__).parent;site=root/'site';repo=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
def sha(b):return hashlib.sha256(b).hexdigest()
with (root/'build.log').open('w') as log:
 subprocess.run([sys.executable,'-m','pip','wheel','--no-cache-dir','--no-deps','--no-build-isolation','--no-index','--wheel-dir',str(root/'wheels'),str(repo)],stdout=log,stderr=subprocess.STDOUT,check=True)
fem=next((root/'wheels').glob('*.whl'));solver=next((root.parent/'r8-ge-distributed-programme-installed-v1/wheels').glob('*.whl'))
with (root/'install.log').open('w') as log:
 subprocess.run([sys.executable,'-m','pip','install','--no-cache-dir','--no-deps','--no-index','--target',str(site),str(fem),str(solver)],stdout=log,stderr=subprocess.STDOUT,check=True)
artifacts={}
for package,wheel,source in [('anyfem',fem,repo/'src'),('anysolver',solver,Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001/src'))]:
 modules={}
 with zipfile.ZipFile(wheel) as z:
  for p in (source/package).rglob('*.py'):
   name=p.relative_to(source).as_posix();data=p.read_bytes()
   assert data==z.read(name)==(site/name).read_bytes(),name
   modules[name]=sha(data)
 artifacts[package]=dict(wheel=wheel.name,sha256=sha(wheel.read_bytes()),modules=modules)
artifacts['fixtures']={p.relative_to(root).as_posix():sha(p.read_bytes()) for folder in ('fixtures','examples') for p in (root/folder).rglob('*') if p.is_file()}
(root/'artifact.json').write_text(json.dumps(artifacts,indent=2))
print(json.dumps({k:dict(sha256=v['sha256'],modules=len(v['modules'])) for k,v in artifacts.items() if k!='fixtures'}))
