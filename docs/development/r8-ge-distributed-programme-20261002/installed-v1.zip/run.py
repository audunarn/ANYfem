from pathlib import Path
import sys,json,importlib.util
root=Path(__file__).parent;site=root/'site'
if len(sys.argv)>1:
    from importlib import metadata
    import anysolver,anyfem,numba,threadpoolctl,pytest
    def runtime():
        pools=threadpoolctl.threadpool_info();assert pools and all(p['num_threads']==1 for p in pools)
        assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
        return pools
    runtime()
    assert all(Path(m.__file__).resolve().is_relative_to(site.resolve()) for m in (anysolver,anyfem))
    names=json.loads((root/'selected.json').read_text())
    code=pytest.main(['-q','-c',str(root/'fixtures/pytest.ini'),'-p','no:cacheprovider','--basetemp='+str(Path.cwd()/'basetemp'),'--junitxml='+str(Path.cwd()/'junit.xml'),*[str(root/'fixtures'/n) for n in names]])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(site.resolve()) for p in imports.values())
    Path('runtime.json').write_text(json.dumps(dict(exit_code=int(code),imports=imports,pools=runtime(),jit_disabled=bool(numba.config.DISABLE_JIT),numba_threads=numba.get_num_threads(),python=sys.version,dependencies={n:metadata.version(n) for n in ('numpy','scipy','numba','ANYsolver','ANYfem','ANYmaterial','pytest')}),indent=2)+'\n')
    sys.exit(code)
else:
    spec=importlib.util.spec_from_file_location('supervisor',root.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
    s.ENV['PYTHONPATH']=str(site);s.ENV['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
    result=s.supervised([sys.executable,str(Path(__file__)),'child'],root/'tests-v1')
    print(json.dumps({k:result[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
