from pathlib import Path
import hashlib,importlib.util,json,os,runpy,shutil,sys,zipfile

ROOT=Path(__file__).resolve().parent
REPO=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
OLD=ROOT.parent/'r8-anyfem-b2-body-consumer-v3'
SOLVER_ART=ROOT.parent/'r8-b2-loaded-sections-installed-v2'
SITE=OLD/'site'
SUP=ROOT.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py'
FIXTURES=('examples/stiffened_shell_coupled_plastic_history_consumer.py',
          'tests/test_stiffened_shell_simultaneous_history_consumer.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def prepare():
    identities={}
    for package,repo,manifest_file,wheels,expected in (
        ('anyfem',REPO,OLD/'source-manifest.json',OLD/'wheels',
         '02a419916f093ab8711a943cb96f5495b44503a4158717f100c960984db5bab4'),
        ('anysolver',SOLVER,SOLVER_ART/'solver-source-manifest.json',SOLVER_ART/'solver-artifact/wheels',
         '4c14d0942410f97b6e2ab397eb0d4e567cbff4169c05b391c5685c4df40d3b7c')):
        manifest=json.loads(manifest_file.read_text());wheel,=wheels.glob('*.whl')
        assert sha(wheel)==expected
        with zipfile.ZipFile(wheel) as z:
            names={n for n in z.namelist() if n.startswith(package+'/') and n.endswith('.py')}
            assert names=={n.removeprefix('src/') for n in manifest}
            for name,digest in manifest.items():
                rel=name.removeprefix('src/')
                assert sha(repo/name)==sha(SITE/rel)==hashlib.sha256(z.read(rel)).hexdigest()==digest
        shutil.copy2(manifest_file,ROOT/(package+'-source-manifest.json'))
        identities[package]=dict(wheel=str(wheel),wheel_sha256=expected,modules=len(manifest),site=str(SITE))
    for name in FIXTURES:
        dest=ROOT/'fixtures'/name;dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():assert sha(dest)==sha(REPO/name),'changed fixture requires a new run version'
        else:shutil.copy2(REPO/name,dest)
    (ROOT/'fixture-manifest.json').write_text(json.dumps({n:sha(REPO/n) for n in FIXTURES},indent=2)+'\n',encoding='utf-8')
    (ROOT/'artifact-identities.json').write_text(json.dumps(identities,indent=2)+'\n',encoding='utf-8')
    (ROOT/'fixtures/pytest.ini').write_text('[pytest]\njunit_family = legacy\n',encoding='utf-8')

def child(mode):
    from importlib import metadata
    import anyfem,anysolver,numba,threadpoolctl
    def runtime():
        pools=threadpoolctl.threadpool_info()
        assert pools and all(p['num_threads']==1 for p in pools)
        assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
        return pools
    runtime()
    assert all(Path(m.__file__).resolve().is_relative_to(SITE.resolve()) for m in (anyfem,anysolver))
    code=0
    if mode=='test':
        import pytest
        code=pytest.main(['-q','-c',str(ROOT/'fixtures/pytest.ini'),
            '--basetemp='+str(Path.cwd()/'basetemp'),
            '--junitxml='+str(Path.cwd()/'junit.xml'),str(ROOT/'fixtures'/FIXTURES[1])])
    elif mode=='example':
        sys.argv=[str(ROOT/'fixtures'/FIXTURES[0])]
        runpy.run_path(sys.argv[0],run_name='__main__')
    else:raise ValueError('exact test/example mode required')
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items()
             if n.startswith(('anysolver','anyfem')) and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(SITE.resolve()) for p in imports.values())
    identity=dict(exit_code=int(code),python=sys.version,imports=imports,pools=runtime(),
        numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),
        dependencies={n:metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','ANYsolver','ANYfem','ANYmesher','ANYfileio','pytest','threadpoolctl','psutil')})
    Path('import-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
    sys.exit(code)

if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='child':child(sys.argv[2])
    elif len(sys.argv)==2 and sys.argv[1] in ('test','example'):
        prepare()
        assert sha(SUP)=='5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
        spec=importlib.util.spec_from_file_location('supervisor',SUP)
        service=importlib.util.module_from_spec(spec);spec.loader.exec_module(service)
        service.ENV.update(PYTHONPATH=os.pathsep.join((str(SITE),str(ROOT/'fixtures'))),
                           PYTHONNOUSERSITE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
        print(json.dumps(service.supervised([sys.executable,str(Path(__file__)),'child',sys.argv[1]],ROOT/sys.argv[1])))
    else:raise ValueError('test or example mode required')
