from pathlib import Path
import sys,json,hashlib,shutil,zipfile,importlib.util
ROOT=Path(__file__).parent
REPO=Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER=Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
SITE=ROOT/'site'
TESTS=('test_stiffened_shell_ge_gravity_consumer.py','test_stiffened_shell_ge_distributed_consumer.py','test_stiffened_shell_ge_distributed_workflow.py','test_stiffened_shell_staged_load_consumer.py','test_stiffened_shell_project.py')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prepare():
    identities={}
    for package,repo,mfile,wheels in [('anyfem',REPO,ROOT/'source-manifest.json',ROOT/'wheels'),('anysolver',SOLVER,ROOT/'solver-source-manifest.json',ROOT.parent/'r8-ge-distributed-installed-v1/wheels')]:
        manifest=json.loads(mfile.read_text());wheel,=wheels.glob('*.whl')
        with zipfile.ZipFile(wheel) as z:
            assert {n for n in z.namelist() if n.startswith(package+'/') and n.endswith('.py')}=={n.removeprefix('src/') for n in manifest}
            for name,digest in manifest.items():
                rel=name.removeprefix('src/')
                assert sha(repo/name)==sha(SITE/rel)==hashlib.sha256(z.read(rel)).hexdigest()==digest
        identities[package]=dict(wheel=str(wheel),sha256=sha(wheel),modules=len(manifest),site=str(SITE))
    records={}
    for name in (*('tests/'+n for n in TESTS),'examples/stiffened_shell_ge_gravity_consumer.py','examples/stiffened_shell_ge_distributed_consumer.py'):
        source=REPO/name;target=ROOT/'fixtures-v2'/name;target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():assert sha(target)==sha(source)
        else:shutil.copy2(source,target)
        records[name]=sha(source)
    (ROOT/'fixtures-v2/pytest.ini').write_text('[pytest]\n')
    (ROOT/'fixture-manifest-v2.json').write_text(json.dumps(records,indent=2)+'\n')
    (ROOT/'artifact-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
def child():
    from importlib import metadata
    import anyfem,anysolver,numba,threadpoolctl,pytest
    def runtime():
        pools=threadpoolctl.threadpool_info()
        assert pools and all(p['num_threads']==1 for p in pools)
        assert numba.get_num_threads()==1 and numba.config.DISABLE_JIT
        return pools
    runtime()
    assert all(Path(m.__file__).resolve().is_relative_to(SITE.resolve()) for m in (anyfem,anysolver))
    code=pytest.main(['-q','-c',str(ROOT/'fixtures-v2/pytest.ini'),'-p','no:cacheprovider','--basetemp='+str(Path.cwd()/'basetemp'),'--junitxml='+str(Path.cwd()/'junit.xml'),str(ROOT/'fixtures-v2/tests/test_stiffened_shell_ge_distributed_workflow.py')])
    imports={n:str(Path(m.__file__).resolve()) for n,m in sys.modules.items() if n.startswith(('anyfem','anysolver')) and getattr(m,'__file__',None)}
    assert all(Path(p).is_relative_to(SITE.resolve()) for p in imports.values())
    record=dict(exit_code=int(code),python=sys.version,imports=imports,pools=runtime(),numba_threads=numba.get_num_threads(),jit_disabled=bool(numba.config.DISABLE_JIT),dependencies={n:metadata.version(n) for n in ('numpy','scipy','numba','ANYmaterial','ANYsolver','ANYfem','ANYmesher','ANYfileio','pytest','threadpoolctl','psutil')})
    Path('runtime.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(code)
if len(sys.argv)>1:child()
else:
    prepare();spec=importlib.util.spec_from_file_location('supervisor',ROOT.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    m.ENV['PYTHONPATH']=str(SITE)
    r=m.supervised([sys.executable,str(ROOT/'run-final.py'),'child'],ROOT/'test-v2')
    print(json.dumps({k:r[k] for k in ('exit_code','elapsed_seconds','sampled_peak_tree_bytes')}))
