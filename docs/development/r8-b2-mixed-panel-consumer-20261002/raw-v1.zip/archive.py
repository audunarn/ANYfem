from pathlib import Path
import hashlib, json, shutil, zipfile

ROOT = Path(__file__).resolve().parent
FEM = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
EVIDENCE = FEM/'docs/development/r8-b2-mixed-panel-consumer-20261002'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
SITE = ROOT/'site'

identity = {}
for package, source, wheel_dir in (
    ('anyfem', FEM, ROOT/'wheels'),
    ('anysolver', SOLVER, ROOT.parent/'r8-b2-mixed-panel-installed-v1/wheels')):
    wheel, = wheel_dir.glob('*.whl')
    with zipfile.ZipFile(wheel) as archive:
        names = {p for p in archive.namelist() if p.startswith(package+'/') and p.endswith('.py')}
        actual = {p.relative_to(source/'src').as_posix() for p in (source/'src'/package).rglob('*.py')}
        assert names == actual
        assert all(archive.read(p) == (SITE/p).read_bytes() == (source/'src'/p).read_bytes() for p in names)
    identity[package] = {'wheel_sha256':sha(wheel), 'matching_modules':len(names)}
(ROOT/'artifact-byte-check.json').write_text(json.dumps(identity, indent=2)+'\n')
assert identity['anyfem']['wheel_sha256'] == '15eb01d0ac2a0ae1e378a676cdf26bd27ea2bd5f0696ff66a374c0dab79b76f6'
assert identity['anysolver']['wheel_sha256'] == 'fb12ac6637098f32477616a402ed3cae79ae28c49edb81ff30d35d57087d75fd'

for relative in ('src/anyfem/solve/stiffened_shell_b2.py', 'src/anyfem/solve/stiffened_shell_project.py',
                 'tests/test_experimental_b2_mixed_panel_consumer.py', 'examples/stiffened_shell_b2_mixed_panel_consumer.py'):
    target = ROOT/'source'/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(FEM/relative, target)

EVIDENCE.mkdir(parents=True, exist_ok=False)
selected = [p for p in ROOT.iterdir() if p.is_file()]
for folder in ('source-run','repair-run','repair-v3-run','installed-run','example-1-run','example-10-run',
               'example-100-run','fixtures','fixtures-v2','fixtures-v3','source','wheels'):
    selected.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
selected = sorted(set(selected))
archive = EVIDENCE/'raw-v1.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for p in selected: z.write(p, p.relative_to(ROOT).as_posix())
manifest = {'classification':'experimental consumer integration; not programme acceptance',
    'original_root':str(ROOT), 'consumer_parent':'350c98016b35e861bfb0a43e2c24fe1c0ee48039',
    'solver_product':'46026dca55eb939bb7f1051542239a693e5890aa', 'artifacts':identity,
    'archive_sha256':sha(archive), 'archive_bytes':archive.stat().st_size, 'members':len(selected),
    'member_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in selected}}
(EVIDENCE/'raw-v1.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('archive_sha256','archive_bytes','members','artifacts')}))
