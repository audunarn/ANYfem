from pathlib import Path
import hashlib, importlib.util, json, os, runpy, shutil, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER = ROOT.parent/'r8-b2-mixed-panel-installed-v1'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
FIXTURES = ('test_experimental_b2_mixed_panel_consumer.py',
    'test_experimental_b2_stiffened_shell_consumer.py',
    'test_stiffened_shell_b2_nodal_footprint_consumer.py',
    'test_stiffened_shell_b2_reference_modal_consumer.py',
    'test_stiffened_shell_project.py')

def prepare():
    (ROOT/'fixtures').mkdir()
    for name in FIXTURES:
        shutil.copy2(SOURCE/'tests'/name, ROOT/'fixtures'/name)
    shutil.copy2(SOURCE/'examples/stiffened_shell_b2_mixed_panel_consumer.py', ROOT/'example.py')
    (ROOT/'pytest.ini').write_text('[pytest]\n')
    manifest = {p.relative_to(SOURCE).as_posix(): sha(p)
                for p in sorted((SOURCE/'src/anyfem').rglob('*.py'))}
    (ROOT/'source-manifest.json').write_text(json.dumps(manifest, indent=2))
    supervisor = ROOT.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py'
    assert sha(supervisor) == '5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
    shutil.copy2(supervisor, ROOT/'supervisor.py')

def build():
    build = ROOT/'build-source'
    build.mkdir()
    shutil.copytree(SOURCE/'src', build/'src', ignore=shutil.ignore_patterns('__pycache__', '*.egg-info'))
    for name in ('pyproject.toml', 'MANIFEST.in', 'README.md', 'CHANGELOG.md', 'LICENSE',
                 'NOTICE', 'THIRD_PARTY_NOTICES.md', 'dependency-licenses.json', 'run_gui.py'):
        shutil.copy2(SOURCE/name, build/name)
    shutil.copytree(SOURCE/'docs', build/'docs')
    (ROOT/'wheels').mkdir()
    subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-deps', '--no-build-isolation',
        '--no-cache-dir', '--wheel-dir', str(ROOT/'wheels'), str(build)], check=True, timeout=120)
    consumer, = (ROOT/'wheels').glob('*.whl')
    solver, = (SOLVER/'wheels').glob('anysolver*.whl')
    assert sha(solver) == 'fb12ac6637098f32477616a402ed3cae79ae28c49edb81ff30d35d57087d75fd'
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-index', '--no-deps',
        '--no-cache-dir', '--target', str(ROOT/'site'), str(solver), str(consumer)], check=True, timeout=60)
    print(json.dumps({'consumer_wheel': sha(consumer), 'solver_wheel': sha(solver)}))

def child(label):
    from importlib import metadata
    import anyfem, anysolver, numba, numpy, scipy, threadpoolctl
    manifest = json.loads((ROOT/'source-manifest.json').read_text())
    assert all(sha(SOURCE/p) == value for p, value in manifest.items()), 'source changed'
    fem_site = SOURCE/'src' if label == 'source' else ROOT/'site'
    solver_site = SOLVER/'site' if label == 'source' else ROOT/'site'
    assert Path(anyfem.__file__).resolve().is_relative_to(fem_site.resolve())
    assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
    assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
    pools = threadpoolctl.threadpool_info()
    assert pools and all(pool['num_threads'] == 1 for pool in pools)
    if label != 'source':
        wheel, = (ROOT/'wheels').glob('*.whl')
        with zipfile.ZipFile(wheel) as archive:
            modules = {p for p in archive.namelist() if p.startswith('anyfem/') and p.endswith('.py')}
            assert modules == {p.removeprefix('src/') for p in manifest}
            assert all(archive.read(p) == (ROOT/'site'/p).read_bytes() == (SOURCE/'src'/p).read_bytes()
                       for p in modules)
    identity = {'label': label, 'python': sys.version, 'anyfem': anyfem.__file__,
        'anysolver': anysolver.__file__, 'pools': pools, 'numba_threads': numba.get_num_threads(),
        'jit_disabled': bool(numba.config.DISABLE_JIT), 'source_modules': len(manifest),
        'dependencies': {name: metadata.version(name) for name in ('numpy', 'scipy', 'numba',
            'pytest', 'threadpoolctl', 'ANYsolver', 'ANYfem', 'ANYmaterial', 'ANYmesher', 'ANYfileio')},
        'fixtures': {name: sha(ROOT/'fixtures'/name) for name in FIXTURES}}
    (ROOT/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
    code = 0
    if label.startswith('example-'):
        count = int(label.split('-')[-1])
        sys.argv = [str(ROOT/'example.py'), str(ROOT/(label+'.anyfem')), '--cases', str(count)]
        runpy.run_path(str(ROOT/'example.py'), run_name='__main__')
    else:
        import pytest
        code = pytest.main(['-q', '-c', str(ROOT/'pytest.ini'), '-p', 'no:cacheprovider',
            '--basetemp', str(ROOT/(label+'-tmp')), '--junitxml', str(ROOT/(label+'.xml')),
            *[str(ROOT/'fixtures'/name) for name in FIXTURES]])
    imports = {name: mod.__file__ for name, mod in sys.modules.items()
               if name.startswith(('anyfem', 'anysolver')) and getattr(mod, '__file__', None)}
    assert all(Path(path).resolve().is_relative_to((fem_site if name.startswith('anyfem') else solver_site).resolve())
               for name, path in imports.items()), 'source fallback'
    (ROOT/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
    assert numba.get_num_threads() == 1 and all(pool['num_threads'] == 1 for pool in threadpoolctl.threadpool_info())
    print(json.dumps({'label': label, 'exit': code, 'checked_imports': len(imports)}))
    sys.exit(code)

def supervise(label):
    spec = importlib.util.spec_from_file_location('owned_supervisor', ROOT/'supervisor.py')
    service = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(service)
    paths = (SOURCE/'src', SOLVER/'site', ROOT/'fixtures') if label == 'source' else (ROOT/'site', ROOT/'fixtures')
    service.ENV.update(PYTHONPATH=os.pathsep.join(map(str, paths)), PYTHONNOUSERSITE='1')
    result = service.supervised([sys.executable, '-u', str(Path(__file__)), 'child', label], ROOT/(label+'-run'))
    print(json.dumps(result))

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'prepare': prepare()
    elif mode == 'build': build()
    elif mode == 'child': child(sys.argv[2])
    else: supervise(mode)
