from pathlib import Path
from hashlib import sha256
from io import BytesIO
import json, os, zipfile

root = Path(__file__).resolve().parent
temp = root.parent
fem = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
solver = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
home = fem/'docs/development/r8-b2-body-acceleration-consumer-20261002'
payload = {}
for version in ('v1', 'v2', 'v3'):
    run = temp/('r8-anyfem-b2-body-consumer-'+version)
    for p in sorted(run.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:
            continue
        relative = p.relative_to(run)
        if any(part in ('site', 'build-source', 'source-tmp', 'installed-tmp',
                        'repair-cancellation-tmp', 'repair-compatibility-tmp')
               for part in relative.parts):
            continue
        payload[version+'/'+relative.as_posix()] = p.read_bytes()
    # Retain the two invoked product adapters even for pre-review source runs.
    manifest = json.loads((run/'source-manifest.json').read_text())
    for name in ('src/anyfem/solve/stiffened_shell_b2.py',
                 'src/anyfem/solve/stiffened_shell_project.py'):
        data = (fem/name).read_bytes()
        if sha256(data).hexdigest() != manifest[name]:
            before = '''            required_exports = ("B2ReferenceBodyLoad", "B2LoadedMemberSections",
                "B2BodyLoadedPanelResult", "B2BodyLoadedFootprintResult",
                "B2BodyLoadedPanelSelectedCase", "B2BodyLoadedFootprintSelectedCase")
            missing = tuple(name for name in required_exports
                            if not isinstance(getattr(stiffened_shell, name, None), type))
            if missing:
                raise ValueError("installed solver lacks public typed B2 body-load recovery exports: "
                                 + ", ".join(missing))
            cap = getattr(owner, "capabilities", None)
            if (not callable(getattr(owner, "body_acceleration_load", None)) or'''
            after = '''            cap = getattr(owner, "capabilities", None)
            if (getattr(stiffened_shell, "B2ReferenceBodyLoad", None) is None or
                    not callable(getattr(owner, "body_acceleration_load", None)) or'''
            text = data.decode('utf-8')
            assert before in text, name
            data = text.replace(before, after, 1).encode('utf-8')
        assert sha256(data).hexdigest() == manifest[name], name
        payload[version+'/invoked-source/'+name] = data

for name in ('src/anyfem/solve/stiffened_shell_b2.py',
             'src/anyfem/solve/stiffened_shell_project.py',
             'tests/test_experimental_b2_body_acceleration_consumer.py',
             'examples/experimental_b2_body_acceleration.py',
             'examples/stiffened_shell_b2_mixed_panel_consumer.py'):
    payload['candidate/'+name] = (fem/name).read_bytes()
payload['retain.py'] = Path(__file__).read_bytes()
# Credential comparison is wholly in memory; never display values or copy the
# contaminated historical archive into this collection.
historical = solver/'docs/agent_plans/development/r8-b2-mixed-reference-modes-20261002/us3-modal-canary-v1.zip'
with zipfile.ZipFile(historical) as z:
    name, = [n for n in z.namelist() if n.endswith('execution-identity.json')]
    env = json.loads(z.read(name))['environment']
    secrets = [str(v).encode() for k,v in env.items() if v and k.endswith('API_KEY')]
secrets += [v.encode() for k,v in os.environ.items() if v and k.endswith('API_KEY')]
for name,data in payload.items():
    if any(value in data for value in secrets):
        raise RuntimeError('credential scan failed: '+name)
    if name.endswith('.whl'):
        with zipfile.ZipFile(BytesIO(data)) as z:
            if any(value in z.read(n) for n in z.namelist() for value in secrets):
                raise RuntimeError('credential scan failed in wheel')
home.mkdir(exist_ok=False)
archive = home/'raw-v1.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(payload.items()): z.writestr(name,data)
identity = dict(archive_sha256=sha256(archive.read_bytes()).hexdigest(),
    bytes=archive.stat().st_size,members=len(payload),
    credential_value_scan='clear; known values inspected in memory, historical archive not copied',
    consumer_base='cabb6ed',solver_source='613e43f7',
    consumer_wheel_sha256=json.loads((root/'installed-identity.json').read_text())['consumer_wheel_sha256'],
    solver_wheel_sha256=json.loads((root/'installed-identity.json').read_text())['solver_wheel_sha256'],
    inventory={name:dict(bytes=len(data),sha256=sha256(data).hexdigest())
               for name,data in sorted(payload.items())})
(home/'raw-v1.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:identity[k] for k in ('archive_sha256','bytes','members','credential_value_scan')}))
