"""Owned serial supervisor for one restricted matched-reference development batch."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, time
import psutil

ROOT = Path(__file__).resolve().parent
REPO = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
SITE = ROOT/'site'
EXE = Path('C:/Github/ANYsolver/.qualification/b3-ge-e4-pl/calculix-223/CalculiX-2.23.0-win-x64/bin/ccx.exe')
SHA = '27a9426a1ee2f72c38fbe892e0ffaf38e14867628ffd0235770261b6f3ec9c5f'
ENV = os.environ.copy()
ENV.update(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1',
    NUMBA_NUM_THREADS='1', NUMBA_DISABLE_JIT='1', CCX_NPROC_RESULTS='1',
    CCX_NPROC_EQUATION_SOLVER='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def supervised(command, folder):
    folder.mkdir(parents=True, exist_ok=False)
    started, peak, threads, limit = time.monotonic(), 0, 0, None
    observed = False
    with (folder/'stdout.log').open('x') as out, (folder/'stderr.log').open('x') as err:
        p = subprocess.Popen(command, cwd=folder, env=ENV, stdout=out, stderr=err)
        proc = psutil.Process(p.pid); tree = [proc]
        try:
            while p.poll() is None:
                try:
                    tree = [proc]+proc.children(recursive=True)
                    rss = sum(x.memory_info().rss for x in tree if x.is_running())
                    peak = max(peak, rss)
                    threads = max(threads, sum(x.num_threads() for x in tree if x.is_running()))
                    observed = True
                except psutil.NoSuchProcess:
                    pass
                except psutil.AccessDenied:
                    limit = 'resource observation denied'
                if time.monotonic()-started > 600: limit = 'time'
                if peak > 1024**3: limit = 'memory'
                if limit:
                    for x in reversed(tree):
                        try: x.kill()
                        except psutil.NoSuchProcess: pass
                    break
                time.sleep(.02)
            code = p.wait(timeout=20)
        finally:
            if p.poll() is None:
                for x in reversed(tree):
                    try: x.kill()
                    except psutil.NoSuchProcess: pass
    record = dict(command=command, exit_code=code, elapsed_seconds=time.monotonic()-started,
        sampled_peak_tree_bytes=peak if observed else None,
        sampled_max_process_tree_threads=threads if observed else None,
        resource_observed=observed, resource_limit=limit, timeout_seconds=600,
        memory_limit_bytes=1024**3, supervisor_sha256=sha(Path(__file__)),
        environment={k:ENV[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
        'NUMBA_NUM_THREADS','NUMBA_DISABLE_JIT','CCX_NPROC_RESULTS','CCX_NPROC_EQUATION_SOLVER')})
    (folder/'execution.json').write_text(json.dumps(record, indent=2)+'\n')
    if code or limit: raise RuntimeError(f'failed child: {folder}; exit={code}; limit={limit}')
    return record

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=('native','external'))
    parser.add_argument('--nx',type=int,required=True)
    parser.add_argument('--ny',type=int,required=True)
    parser.add_argument('--sign',type=int,choices=(-1,1),required=True)
    parser.add_argument('--profile',choices=('b2','ge'),default='b2')
    args=parser.parse_args()
    label=f'{args.mode}-{args.profile if args.mode=="native" else "ccx"}-{args.nx}x{args.ny}-s{args.sign}'
    target=ROOT/label
    if args.mode=='native':
        script=ROOT/'native-runner.py'
        if not script.exists(): shutil.copy2(REPO/'scripts/r8_e02_native_rigid_tip.py',script)
        if sha(script)!=sha(REPO/'scripts/r8_e02_native_rigid_tip.py'):
            raise RuntimeError('native runner changed; preserve old batch and choose a new version')
        command=[sys.executable,'-u',str(script),'--site',str(SITE),'--output',str(target/'outputs'),
            '--nx',str(args.nx),'--ny',str(args.ny),'--sign',str(args.sign),'--profile',args.profile]
        record=supervised(command,target)
        print(json.dumps(dict(label=label, elapsed_seconds=record['elapsed_seconds'],
            peak=record['sampled_peak_tree_bytes'])))
    else:
        sys.path.insert(0,str(REPO/'scripts'))
        import r8_e02_rigid_tip_reference as helper
        if sha(EXE)!=SHA: raise RuntimeError('external executable identity changed')
        target.mkdir(exist_ok=False)
        shutil.copy2(Path(helper.__file__), target/'reference-helper.py')
        for name in ('Fz','Mx','My'):
            folder=target/name
            # Supervisor owns folder creation. Deck is first staged separately.
            deck,meta=helper.build_deck(args.nx,args.ny,args.sign,name)
            staged=target/(name+'.inp'); staged.write_bytes(deck.encode('ascii'))
            if sha(staged)!=meta['deck_sha256']:
                raise RuntimeError('staged deck identity does not match helper metadata')
            command=[str(EXE),'-i',str(staged.with_suffix(''))]
            record=supervised(command,folder)
            # CCX writes files beside the input stem, retained there.
            dat=staged.with_suffix('.dat').read_text()
            err=(folder/'stderr.log').read_text()
            sta=staged.with_suffix('.sta').read_text().splitlines()
            completed=[line.split() for line in sta if line.strip() and line.strip()[0].isdigit()]
            if len(completed)!=1 or completed[0][:2]!=['1','1'] or float(completed[0][-1])!=1.:
                raise RuntimeError('complete single-step .sta inventory required')
            if err.strip(): raise RuntimeError('nonempty external stderr')
            parsed=helper.parse_result(dat,(folder/'stdout.log').read_text(),meta)
            identity=dict(executable=str(EXE),executable_sha256=SHA,
                deck_sha256=sha(staged),helper_sha256=sha(Path(helper.__file__)),metadata=meta)
            (folder/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
            (folder/'result.json').write_text(json.dumps(parsed,indent=2)+'\n')
            print(json.dumps(dict(label=label,load=name,elapsed_seconds=record['elapsed_seconds'],
                pairing_J=parsed['conjugate_external_work_J'],
                rotations=parsed['patch_rot_theta_rad'],
                moment=parsed['actual_root_moment_Nm'])))

if __name__=='__main__': main()
