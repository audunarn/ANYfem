from pathlib import Path
import hashlib, importlib.util, json, os, runpy, shutil, subprocess, sys, zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = Path('C:/Github/ANYfem/.worktrees/experimental-ge-panel-consumer')
SOLVER = Path('C:/Users/AudunArnesenNyhus/AppData/Local/Temp/r8-b2-loaded-sections-installed-v2/solver-artifact')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
FIXTURES = ('test_experimental_b2_body_acceleration_consumer.py', 'test_experimental_b2_mixed_reference_modal_consumer.py', 'test_experimental_b2_mixed_panel_consumer.py',
    'test_experimental_b2_stiffened_shell_consumer.py',
    'test_stiffened_shell_b2_nodal_footprint_consumer.py',
    'test_stiffened_shell_b2_reference_modal_consumer.py',
    'test_stiffened_shell_project.py')

def prepare():
    (ROOT/'fixtures').mkdir()
    shutil.copy2(SOLVER.parent/'solver-source-manifest.json', ROOT/'solver-source-manifest.json')
    for name in FIXTURES:
        shutil.copy2(SOURCE/'tests'/name, ROOT/'fixtures'/name)
    shutil.copy2(SOURCE/'examples/experimental_b2_body_acceleration.py', ROOT/'example.py')
    shutil.copy2(SOURCE/'examples/stiffened_shell_b2_mixed_panel_consumer.py', ROOT/'stiffened_shell_b2_mixed_panel_consumer.py')
    (ROOT/'pytest.ini').write_text('[pytest]\n')
    manifest = {p.relative_to(SOURCE).as_posix(): sha(p)
                for p in sorted((SOURCE/'src/anyfem').rglob('*.py'))}
    (ROOT/'source-manifest.json').write_text(json.dumps(manifest, indent=2))
    supervisor = ROOT.parent/'r8-b2-panel-resolution-installed-v1/matched-run.py'
    assert sha(supervisor) == '5837645ddf40e591451cbd58f8975ce8f026cb908e750044b848c8c04dcae5d4'
    shutil.copy2(supervisor, ROOT/'supervisor.py')

def build():
    build = ROOT/'build-source'
    build.mkdir()
    shutil.copytree(SOURCE/'src', build/'src', ignore=shutil.ignore_patterns('__pycache__', '*.egg-info'))
    for name in ('pyproject.toml', 'MANIFEST.in', 'README.md', 'CHANGELOG.md', 'LICENSE',
                 'NOTICE', 'THIRD_PARTY_NOTICES.md', 'dependency-licenses.json', 'run_gui.py'):
        shutil.copy2(SOURCE/name, build/name)
    for p in (SOURCE/'docs').rglob('*.md'):
        relative=p.relative_to(SOURCE);(build/relative).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,build/relative)
    (ROOT/'wheels').mkdir()
    subprocess.run([sys.executable, '-m', 'pip', 'wheel', '--no-index', '--no-deps', '--no-build-isolation',
        '--no-cache-dir', '--wheel-dir', str(ROOT/'wheels'), str(build)], check=True, timeout=120)
    consumer, = (ROOT/'wheels').glob('*.whl')
    solver, = (SOLVER/'wheels').glob('anysolver*.whl')
    assert sha(solver) == '4c14d0942410f97b6e2ab397eb0d4e567cbff4169c05b391c5685c4df40d3b7c'
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--no-index', '--no-deps',
        '--no-cache-dir', '--target', str(ROOT/'site'), str(solver), str(consumer)], check=True, timeout=60)
    print(json.dumps({'consumer_wheel': sha(consumer), 'solver_wheel': sha(solver)}))

def child(label):
    from importlib import metadata
    import anyfem, anysolver, numba, numpy, scipy, threadpoolctl
    manifest = json.loads((ROOT/'source-manifest.json').read_text())
    assert all(sha(SOURCE/p) == value for p, value in manifest.items()), 'source changed'
    source_phase = label == 'source' or label.startswith('repair')
    fixtures = ROOT/'fixtures'
    fem_site = SOURCE/'src' if source_phase else ROOT/'site'
    solver_site = SOLVER/'site' if source_phase else ROOT/'site'
    assert Path(anyfem.__file__).resolve().is_relative_to(fem_site.resolve())
    assert Path(anysolver.__file__).resolve().is_relative_to(solver_site.resolve())
    assert numba.config.DISABLE_JIT and numba.get_num_threads() == 1
    pools = threadpoolctl.threadpool_info()
    assert pools and all(pool['num_threads'] == 1 for pool in pools)
    solver_manifest = json.loads((ROOT/'solver-source-manifest.json').read_text())
    solver_source = Path('C:/Github/ANYsolver/.perf2-worktrees/stiffened-main-reconcile-20261001')
    solver_wheel, = (SOLVER/'wheels').glob('*.whl')
    assert sha(solver_wheel) == '4c14d0942410f97b6e2ab397eb0d4e567cbff4169c05b391c5685c4df40d3b7c'
    with zipfile.ZipFile(solver_wheel) as archive:
        names = {p for p in archive.namelist() if p.startswith('anysolver/') and p.endswith('.py')}
        assert names == {p.removeprefix('src/') for p in solver_manifest}
        for p,digest in solver_manifest.items():
            relative=p.removeprefix('src/')
            assert sha(solver_source/p) == digest
            assert archive.read(relative) == (solver_site/relative).read_bytes() == (solver_source/p).read_bytes()
    if not source_phase:
        wheel, = (ROOT/'wheels').glob('*.whl')
        with zipfile.ZipFile(wheel) as archive:
            modules = {p for p in archive.namelist() if p.startswith('anyfem/') and p.endswith('.py')}
            assert modules == {p.removeprefix('src/') for p in manifest}
            assert all(archive.read(p) == (ROOT/'site'/p).read_bytes() == (SOURCE/'src'/p).read_bytes()
                       for p in modules)
    identity = {'label': label, 'python': sys.version, 'anyfem': anyfem.__file__,
        'anysolver': anysolver.__file__, 'pools': pools, 'numba_threads': numba.get_num_threads(),
        'jit_disabled': bool(numba.config.DISABLE_JIT), 'source_modules': len(manifest), 'solver_modules': len(solver_manifest), 'solver_wheel_sha256': sha(solver_wheel),
        'consumer_wheel_sha256': None if source_phase else sha(wheel),
        'dependencies': {name: metadata.version(name) for name in ('numpy', 'scipy', 'numba',
            'pytest', 'threadpoolctl', 'ANYsolver', 'ANYfem', 'ANYmaterial', 'ANYmesher', 'ANYfileio')},
        'example_sha256': sha(ROOT/'example.py'), 'fixtures': {name: sha(fixtures/name) for name in FIXTURES}}
    (ROOT/(label+'-identity.json')).write_text(json.dumps(identity, indent=2))
    code = 0
    if label.startswith('example-'):
        mesh, count = label.removeprefix('example-').rsplit('-', 1)
        sys.argv = [str(ROOT/'example.py'), str(ROOT/(label+'.anyfem')), '--mesh', mesh, '--cases', count]
        runpy.run_path(str(ROOT/'example.py'), run_name='__main__')
    else:
        import pytest
        targets = ([str(fixtures/'test_experimental_b2_mixed_reference_modal_consumer.py')+'::test_old_static_schema_payloads_and_modal_only_dispatch_unchanged'] if label.startswith('repair') else [str(fixtures/name) for name in FIXTURES])
        code = pytest.main(['-q', '-c', str(ROOT/'pytest.ini'), '-p', 'no:cacheprovider',
            '--basetemp', str(ROOT/(label+'-tmp')), '--junitxml', str(ROOT/(label+'.xml')),
            *targets])
    imports = {name: mod.__file__ for name, mod in sys.modules.items()
               if name.startswith(('anyfem', 'anysolver')) and getattr(mod, '__file__', None)}
    assert all(Path(path).resolve().is_relative_to((fem_site if name.startswith('anyfem') else solver_site).resolve())
               for name, path in imports.items()), 'source fallback'
    (ROOT/(label+'-imports.json')).write_text(json.dumps(imports, indent=2))
    assert numba.get_num_threads() == 1 and all(pool['num_threads'] == 1 for pool in threadpoolctl.threadpool_info())
    print(json.dumps({'label': label, 'exit': code, 'checked_imports': len(imports)}))
    sys.exit(code)

def supervise(label):
    spec = importlib.util.spec_from_file_location('owned_supervisor', ROOT/'supervisor.py')
    service = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(service)
    fixtures = ROOT/'fixtures'
    paths = (SOURCE/'src', SOLVER/'site', fixtures) if label == 'source' or label.startswith('repair') else (ROOT/'site', fixtures)
    service.ENV.update(PYTHONPATH=os.pathsep.join(map(str, paths)), PYTHONNOUSERSITE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    result = service.supervised([sys.executable, '-u', str(Path(__file__)), 'child', label], ROOT/(label+'-run'))
    print(json.dumps(result))

if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'prepare': prepare()
    elif mode == 'build': build()
    elif mode == 'child': child(sys.argv[2])
    else: supervise(mode)
